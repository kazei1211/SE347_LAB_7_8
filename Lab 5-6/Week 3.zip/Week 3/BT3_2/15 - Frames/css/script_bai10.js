function goToTop() {
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function back() {
  history.back();
}

function forward() {
  history.forward();
}